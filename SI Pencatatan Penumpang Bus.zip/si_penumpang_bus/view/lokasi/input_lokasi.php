<div id="container">
	<h3>
		<span style="float:right; line-height:2em;">Input Lokasi</span>
		<a href="index.php?page=index_lokasi">
			<i style="font-size:1.4em;" class="icon ion-ios-undo"></i>Kembali
		</a>
	</h3>
	<hr>
	<form method="post" action="index.php?page=insert_lokasi">
		<input type="hidden" value="" name="id_lokasi">
		<label>Nama Lokasi : </label>
		<input type="text" name="lokasi" autofocus><br>
		<button class="button blue"><i class="icon ion-android-checkmark-circle"></i>Simpan</button>
	</form>
</div>